

void ans(char currentlocation,char direction){

switch (currentlocation) {
  case 'B':
    if (direction=='l'){
    printf("C");
    }
    else if(direction=='s'){
        printf("I");
    }
    break;
  case 'C':
    if (direction=='l'){
    printf("E");
    }
    else if(direction=='s'){
        printf("D");
    }
    else if(direction=='r'){
        printf("H");
    }
    break;
  case 'D':
    if (direction=='l'){
    printf("F");
    }
    else if(direction=='r'){
        printf("G");
    }
    break;
  case 'E':
    if (direction=='l'){
    printf("A");
    }
    else if(direction=='r'){
        printf("F");
    }
    break;
  case 'F':
    if (direction=='l'){
        printf("E");
    }
    else if(direction=='r'){
        printf("D");
    }
    break;

  case 'G':
    if (direction=='l'){
    printf("D");
    }
    else if(direction=='r'){
        printf("H");
    }
    break;

  case 'H':
    if (direction=='l'){
    printf("G");
    }
    else if(direction=='r'){
        printf("I");
    }
    break;

  case 'I':
    if (direction=='l'){
    printf("H");
    }
    break;

}
} 

int main()
{
    char currentlocation='C';
    char direction='l';
    ans(currentlocation,direction);
    return 0;
}