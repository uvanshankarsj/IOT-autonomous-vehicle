const express=require("express")
var app=express()
const fetch = require('node-fetch');
var data;
app.set('view engine', 'ejs'); 
var aas="https://poster.keepcalmandposters.com/default/5883725_keep_calm_your_special_delivery_is_on_its_way.png";
let url = "https://gi7aakbbjk.execute-api.us-east-1.amazonaws.com/items/"
//var lit=fetch("https://gi7aakbbjk.execute-api.us-east-1.amazonaws.com/items/%22AD%22")
//console.log(lit)
const bodyParser = require('body-parser')
app.use(express.json());       
app.use(express.urlencoded({extended: true})); 
app.use(express.static('map'));

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/dashboard.html");
});
 

app.post("/", async (req, res) => {
    const username = req.body.ppoint;
    const password = req.body.dpoint;
    var lit=await fetch("https://gi7aakbbjk.execute-api.us-east-1.amazonaws.com/items/%22"+username+password+"%22")
    data = await lit.json();
    console.log(data["route"]);
    res.redirect("/thanks")
});

app.get("/thanks", async (req, res) => {
  // console.log("sucessful")
  res.send("<table><th><img src='https://poster.keepcalmandposters.com/default/5883725_keep_calm_your_special_delivery_is_on_its_way.png'></img></th><th><img src='"<%aas%>"' width='100%' height='100%'></img></th></table>")
});

app.get("/route",(req,res)=>{
  console.log("request accepted")
  res.send(data["route"])
  // res.send(data["route"])
})

// app.post("/block",(req,res)=>{
//   a=req.body.
// })

// app.post("/map",(req,res)=>{
//   a=req.body.ima
//   console.log(a)
// })

app.listen(4000)
